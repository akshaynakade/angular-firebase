export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAtoQ-PmWPwYz3Mx0Kj_DEdBDVm-kGGpK4",
    authDomain: "login-b79b3.firebaseapp.com",
    databaseURL: "https://login-b79b3.firebaseio.com",
    projectId: "login-b79b3",
    storageBucket: "login-b79b3.appspot.com",
    messagingSenderId: "307163699367",
    appId: "1:307163699367:web:8e1887ffd76ef05e14e382",
    measurementId: "G-753KQS5FFB"
  }
};
